package com.usinsa.crm.vo;

public class OtherVO {
	private String coupon_id;
	private String coupon_name;
	private String product_main_category;
	private String discount;
	public String getCoupon_id() {
		return coupon_id;
	}
	public void setCoupon_id(String coupon_id) {
		this.coupon_id = coupon_id;
	}
	public String getCoupon_name() {
		return coupon_name;
	}
	public void setCoupon_name(String coupon_name) {
		this.coupon_name = coupon_name;
	}
	public String getProduct_main_category() {
		return product_main_category;
	}
	public void setProduct_main_category(String product_main_category) {
		this.product_main_category = product_main_category;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	
	
}
