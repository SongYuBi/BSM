package com.usinsa.crm.vo;

public class SizeVO {
	private String product_id;
	private String product_name;
	private String user_id;
	private String user_name;
	private String product_main_category;
	private String order_size_before;
	private String order_size_after;
	private String order_id;
	private String mail_reg_date;
	
	
	public String getMail_reg_date() {
		return mail_reg_date;
	}
	public void setMail_reg_date(String mail_reg_date) {
		this.mail_reg_date = mail_reg_date;
	}
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getProduct_main_category() {
		return product_main_category;
	}
	public void setProduct_main_category(String product_main_category) {
		this.product_main_category = product_main_category;
	}
	public String getOrder_size_before() {
		return order_size_before;
	}
	public void setOrder_size_before(String order_size_before) {
		this.order_size_before = order_size_before;
	}
	public String getOrder_size_after() {
		return order_size_after;
	}
	public void setOrder_size_after(String order_size_after) {
		this.order_size_after = order_size_after;
	}
	
}
