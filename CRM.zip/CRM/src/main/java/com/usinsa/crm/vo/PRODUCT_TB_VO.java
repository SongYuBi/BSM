package com.usinsa.crm.vo;

import java.sql.Date;

public class PRODUCT_TB_VO {

	private String PRODUCT_ID;
	private String PRODUCT_NAME;
	private String PRODUCT_SIZE;
	private String PRODUCT_CNT;
	private String PRODUCT_WEARING_PRICE;
	private String PRODUCT_PRICE;
	private String PRODUCT_MAIN_CATEGORY;
	private String PRODUCT_SUB_CATEGORY;
	private String PRODUCT_SSUB_CATEGORY;
	private String PRODUCT_KEYWORD;
	private String REG_DATE;
	private String ORDER_PRICE;
	
	
	
	
	
	public String getORDER_PRICE() {
		return ORDER_PRICE;
	}
	public void setORDER_PRICE(String oRDER_PRICE) {
		ORDER_PRICE = oRDER_PRICE;
	}
	public String getPRODUCT_ID() {
		return PRODUCT_ID;
	}
	public void setPRODUCT_ID(String pRODUCT_ID) {
		PRODUCT_ID = pRODUCT_ID;
	}
	public String getPRODUCT_NAME() {
		return PRODUCT_NAME;
	}
	public void setPRODUCT_NAME(String pRODUCT_NAME) {
		PRODUCT_NAME = pRODUCT_NAME;
	}
	public String getPRODUCT_SIZE() {
		return PRODUCT_SIZE;
	}
	public void setPRODUCT_SIZE(String pRODUCT_SIZE) {
		PRODUCT_SIZE = pRODUCT_SIZE;
	}
	public String getPRODUCT_CNT() {
		return PRODUCT_CNT;
	}
	public void setPRODUCT_CNT(String pRODUCT_CNT) {
		PRODUCT_CNT = pRODUCT_CNT;
	}
	public String getPRODUCT_WEARING_PRICE() {
		return PRODUCT_WEARING_PRICE;
	}
	public void setPRODUCT_WEARING_PRICE(String pRODUCT_WEARING_PRICE) {
		PRODUCT_WEARING_PRICE = pRODUCT_WEARING_PRICE;
	}
	public String getPRODUCT_PRICE() {
		return PRODUCT_PRICE;
	}
	public void setPRODUCT_PRICE(String pRODUCT_PRICE) {
		PRODUCT_PRICE = pRODUCT_PRICE;
	}
	public String getPRODUCT_MAIN_CATEGORY() {
		return PRODUCT_MAIN_CATEGORY;
	}
	public void setPRODUCT_MAIN_CATEGORY(String pRODUCT_MAIN_CATEGORY) {
		PRODUCT_MAIN_CATEGORY = pRODUCT_MAIN_CATEGORY;
	}
	public String getPRODUCT_SUB_CATEGORY() {
		return PRODUCT_SUB_CATEGORY;
	}
	public void setPRODUCT_SUB_CATEGORY(String pRODUCT_SUB_CATEGORY) {
		PRODUCT_SUB_CATEGORY = pRODUCT_SUB_CATEGORY;
	}
	public String getPRODUCT_SSUB_CATEGORY() {
		return PRODUCT_SSUB_CATEGORY;
	}
	public void setPRODUCT_SSUB_CATEGORY(String pRODUCT_SSUB_CATEGORY) {
		PRODUCT_SSUB_CATEGORY = pRODUCT_SSUB_CATEGORY;
	}
	public String getPRODUCT_KEYWORD() {
		return PRODUCT_KEYWORD;
	}
	public void setPRODUCT_KEYWORD(String pRODUCT_KEYWORD) {
		PRODUCT_KEYWORD = pRODUCT_KEYWORD;
	}
	public String getREG_DATE() {
		return REG_DATE;
	}
	public void setREG_DATE(String rEG_DATE) {
		REG_DATE = rEG_DATE;
	}
	@Override
	public String toString() {
		return "PRODUCT_TB_VO [PRODUCT_ID=" + PRODUCT_ID + ", PRODUCT_NAME=" + PRODUCT_NAME + ", PRODUCT_SIZE="
				+ PRODUCT_SIZE + ", PRODUCT_CNT=" + PRODUCT_CNT + ", PRODUCT_WEARING_PRICE=" + PRODUCT_WEARING_PRICE
				+ ", PRODUCT_PRICE=" + PRODUCT_PRICE + ", PRODUCT_MAIN_CATEGORY=" + PRODUCT_MAIN_CATEGORY
				+ ", PRODUCT_SUB_CATEGORY=" + PRODUCT_SUB_CATEGORY + ", PRODUCT_SSUB_CATEGORY=" + PRODUCT_SSUB_CATEGORY
				+ ", PRODUCT_KEYWORD=" + PRODUCT_KEYWORD + ", REG_DATE=" + REG_DATE + ", ORDER_PRICE=" + ORDER_PRICE
				+ "]";
	}
	
	
	

	
	
	
}
