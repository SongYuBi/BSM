package com.usinsa.crm.service;

import java.util.List;

import com.usinsa.crm.vo.LEVEL_TB_VO;

public interface User_Service {
	List<LEVEL_TB_VO> Level_List() throws Exception;
	
}
