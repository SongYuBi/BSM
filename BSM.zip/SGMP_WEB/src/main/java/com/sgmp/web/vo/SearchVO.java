package com.sgmp.web.vo;

public class SearchVO {
	private String date1;
	private String date2;
	private String prod_wearing_condition;
	private String prod_wearing_company_id;
	private String prod_name;
	private String prod_wearing_id;
	private String prod_wearing_flg;
	private String prod_wearing_release;
	
	
	public String getProd_wearing_release() {
		return prod_wearing_release;
	}
	public void setProd_wearing_release(String prod_wearing_release) {
		this.prod_wearing_release = prod_wearing_release;
	}
	public String getProd_wearing_flg() {
		return prod_wearing_flg;
	}
	public void setProd_wearing_flg(String prod_wearing_flg) {
		this.prod_wearing_flg = prod_wearing_flg;
	}
	public String getDate1() {
		return date1;
	}
	public void setDate1(String date1) {
		this.date1 = date1;
	}
	public String getDate2() {
		return date2;
	}
	public void setDate2(String date2) {
		this.date2 = date2;
	}
	public String getProd_wearing_condition() {
		return prod_wearing_condition;
	}
	public void setProd_wearing_condition(String prod_wearing_condition) {
		this.prod_wearing_condition = prod_wearing_condition;
	}
	public String getProd_wearing_company_id() {
		return prod_wearing_company_id;
	}
	public void setProd_wearing_company_id(String prod_wearing_company_id) {
		this.prod_wearing_company_id = prod_wearing_company_id;
	}
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	public String getProd_wearing_id() {
		return prod_wearing_id;
	}
	public void setProd_wearing_id(String prod_wearing_id) {
		this.prod_wearing_id = prod_wearing_id;
	}
	
	
}
