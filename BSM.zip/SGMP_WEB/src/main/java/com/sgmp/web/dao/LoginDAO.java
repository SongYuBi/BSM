package com.sgmp.web.dao;

import com.sgmp.web.vo.LoginVO;

public interface LoginDAO {
	//로그인DAO
	public int check(LoginVO LoginVO);
}
